#include "PluginProcessor.h"
#include "PluginEditor.h"

CannyOneKnobBassRoomAudioProcessor::CannyOneKnobBassRoomAudioProcessor()
    : AudioProcessor (BusesProperties()
        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "PARAMETERS", createParameterLayout())
{
    drumChainParameter = parameters.getRawParameterValue ("drumchain");
    levelParameter = parameters.getRawParameterValue ("level");
    activeParameter = parameters.getRawParameterValue ("active");
}

juce::AudioProcessorValueTreeState::ParameterLayout CannyOneKnobBassRoomAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "drumchain", 1 },
        "DrumChain",
        juce::NormalisableRange<float> { 0.0f, 1.0f, 0.0001f },
        0.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel ("%")
            .withStringFromValueFunction ([] (float value, int)
            {
                return juce::String (juce::roundToInt (value * 100.0f)) + "%";
            })
            .withValueFromStringFunction ([] (const juce::String& text)
            {
                return juce::jlimit (0.0f, 1.0f, text.getFloatValue() / 100.0f);
            })));

    params.push_back (std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "level", 1 },
        "Level",
        juce::NormalisableRange<float> { -9.0f, 9.0f, 0.01f },
        0.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel ("dB")
            .withStringFromValueFunction ([] (float value, int)
            {
                return juce::String (value, 1) + " dB";
            })
            .withValueFromStringFunction ([] (const juce::String& text)
            {
                return juce::jlimit (-9.0f, 9.0f, text.getFloatValue());
            })));

    params.push_back (std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "active", 1 },
        "Active",
        true));

    return { params.begin(), params.end() };
}

void CannyOneKnobBassRoomAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    const auto channels = getTotalNumOutputChannels();

    compressor.prepare (sampleRate, samplesPerBlock, channels);
    lowCleaner.prepare (sampleRate, samplesPerBlock, channels);
    saturator.prepare (sampleRate, samplesPerBlock, channels);

    processedFloatBuffer.setSize (channels, samplesPerBlock);
    processedDoubleBuffer.setSize (channels, samplesPerBlock);

    drumChainSmoother.reset (sampleRate, 0.035);
    levelGainSmoother.reset (sampleRate, 0.035);
    activeSmoother.reset (sampleRate, 0.020);

    const auto drumChain = drumChainParameter != nullptr ? drumChainParameter->load() : 0.0f;
    const auto levelDb = levelParameter != nullptr ? levelParameter->load() : 0.0f;
    const auto active = activeParameter == nullptr || activeParameter->load() >= 0.5f ? 1.0f : 0.0f;

    drumChainSmoother.setCurrentAndTargetValue (drumChain);
    levelGainSmoother.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (levelDb));
    activeSmoother.setCurrentAndTargetValue (active);
}

void CannyOneKnobBassRoomAudioProcessor::releaseResources()
{
    compressor.reset();
    lowCleaner.reset();
    saturator.reset();
}

bool CannyOneKnobBassRoomAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& mainInput = layouts.getMainInputChannelSet();
    const auto& mainOutput = layouts.getMainOutputChannelSet();

    if (mainInput != mainOutput)
        return false;

    return mainOutput == juce::AudioChannelSet::mono()
        || mainOutput == juce::AudioChannelSet::stereo();
}

void CannyOneKnobBassRoomAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ignoreUnused (midi);
    processAudio (buffer);
}

void CannyOneKnobBassRoomAudioProcessor::processBlock (juce::AudioBuffer<double>& buffer, juce::MidiBuffer& midi)
{
    juce::ignoreUnused (midi);
    processAudio (buffer);
}

template <typename FloatType>
void CannyOneKnobBassRoomAudioProcessor::processAudio (juce::AudioBuffer<FloatType>& buffer)
{
    juce::ScopedNoDenormals noDenormals;

    const auto totalInputChannels = getTotalNumInputChannels();
    const auto totalOutputChannels = getTotalNumOutputChannels();

    for (auto channel = totalInputChannels; channel < totalOutputChannels; ++channel)
        buffer.clear (channel, 0, buffer.getNumSamples());

    const auto numSamples = buffer.getNumSamples();
    const auto numChannels = totalOutputChannels;
    auto& processedBuffer = [] (juce::AudioBuffer<float>& f, juce::AudioBuffer<double>& d) -> juce::AudioBuffer<FloatType>&
    {
        if constexpr (std::is_same_v<FloatType, float>)
            return f;
        else
            return d;
    } (processedFloatBuffer, processedDoubleBuffer);

    processedBuffer.setSize (numChannels, numSamples, false, false, true);

    for (int channel = 0; channel < numChannels; ++channel)
        processedBuffer.copyFrom (channel, 0, buffer, channel, 0, numSamples);

    const auto targetAmount = drumChainParameter != nullptr ? drumChainParameter->load() : 0.0f;
    const auto targetLevelDb = levelParameter != nullptr ? levelParameter->load() : 0.0f;
    const auto targetActive = activeParameter == nullptr || activeParameter->load() >= 0.5f ? 1.0f : 0.0f;

    drumChainSmoother.setTargetValue (targetAmount);
    levelGainSmoother.setTargetValue (juce::Decibels::decibelsToGain (targetLevelDb));
    activeSmoother.setTargetValue (targetActive);

    const auto processAmount = drumChainSmoother.skip (numSamples);

    compressor.setAmount (processAmount);
    lowCleaner.setAmount (processAmount);
    saturator.setAmount (processAmount);

    compressor.processBlock (processedBuffer);
    lowCleaner.processBlock (processedBuffer);
    saturator.processBlock (processedBuffer);

    for (int sample = 0; sample < numSamples; ++sample)
    {
        const auto levelGain = levelGainSmoother.getNextValue();
        const auto wet = activeSmoother.getNextValue();

        for (int channel = 0; channel < numChannels; ++channel)
        {
            const auto drySample = buffer.getSample (channel, sample);
            const auto wetSample = processedBuffer.getSample (channel, sample);
            buffer.setSample (channel, sample, (FloatType) ((drySample + (wetSample - drySample) * wet) * levelGain));
        }
    }
}

void CannyOneKnobBassRoomAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto state = parameters.copyState().createXml())
        copyXmlToBinary (*state, destData);
}

void CannyOneKnobBassRoomAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto state = getXmlFromBinary (data, sizeInBytes))
        if (state->hasTagName (parameters.state.getType()))
            parameters.replaceState (juce::ValueTree::fromXml (*state));
}

juce::AudioProcessorEditor* CannyOneKnobBassRoomAudioProcessor::createEditor()
{
    return new CannyOneKnobBassRoomAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new CannyOneKnobBassRoomAudioProcessor();
}
