#pragma once

#include <JuceHeader.h>
#include "DSP/BassRoomCompressor.h"
#include "DSP/BassRoomDynamicLowCleaner.h"
#include "DSP/BassRoomSaturator.h"

class CannyOneKnobBassRoomAudioProcessor final : public juce::AudioProcessor
{
public:
    CannyOneKnobBassRoomAudioProcessor();
    ~CannyOneKnobBassRoomAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlock (juce::AudioBuffer<double>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getValueTreeState() { return parameters; }
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

private:
    template <typename FloatType>
    void processAudio (juce::AudioBuffer<FloatType>& buffer);

    juce::AudioProcessorValueTreeState parameters;
    std::atomic<float>* drumChainParameter = nullptr;
    std::atomic<float>* levelParameter = nullptr;
    std::atomic<float>* activeParameter = nullptr;

    BassRoomCompressor compressor;
    BassRoomDynamicLowCleaner lowCleaner;
    BassRoomSaturator saturator;

    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> drumChainSmoother;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> levelGainSmoother;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> activeSmoother;

    juce::AudioBuffer<float> processedFloatBuffer;
    juce::AudioBuffer<double> processedDoubleBuffer;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (CannyOneKnobBassRoomAudioProcessor)
};
