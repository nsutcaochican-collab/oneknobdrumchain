#include "BassRoomSaturator.h"

void BassRoomSaturator::prepare (double newSampleRate, int maxBlockSize, int numChannels)
{
    juce::ignoreUnused (maxBlockSize);
    sampleRate = newSampleRate;

    const auto channels = (size_t) juce::jmax (1, numChannels);
    highPassFilters.resize (channels);
    lowPassFilters.resize (channels);

    updateFilters();
    reset();
}

void BassRoomSaturator::reset()
{
    for (auto& filter : highPassFilters)
        filter.reset();

    for (auto& filter : lowPassFilters)
        filter.reset();
}

void BassRoomSaturator::setAmount (float newAmount)
{
    amount = juce::jlimit (0.0f, 1.0f, newAmount);
    drive = juce::jmap (amount, 0.0f, 0.45f);
    mix = juce::jmap (amount, 0.0f, 0.35f);
}

void BassRoomSaturator::updateFilters()
{
    const auto highPass = juce::dsp::IIR::Coefficients<float>::makeHighPass (sampleRate, 1500.0);
    const auto lowPass = juce::dsp::IIR::Coefficients<float>::makeLowPass (sampleRate, 5000.0);

    for (auto& filter : highPassFilters)
        filter.coefficients = highPass;

    for (auto& filter : lowPassFilters)
        filter.coefficients = lowPass;
}
