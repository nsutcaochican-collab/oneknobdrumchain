#include "BassRoomCompressor.h"

void BassRoomCompressor::prepare (double newSampleRate, int maxBlockSize, int numChannels)
{
    juce::ignoreUnused (maxBlockSize);
    sampleRate = newSampleRate;
    envelope.assign ((size_t) juce::jmax (1, numChannels), 0.0f);
    updateCoefficients();
}

void BassRoomCompressor::reset()
{
    std::fill (envelope.begin(), envelope.end(), 0.0f);
}

void BassRoomCompressor::setAmount (float newAmount)
{
    amount = juce::jlimit (0.0f, 1.0f, newAmount);

    ratio = 2.0f;
    attackMs = juce::jmap (amount, 80.0f, 150.0f);
    releaseMs = juce::jmap (amount, 100.0f, 180.0f);
    maxGainReductionDb = -5.0f;

    if (amount <= 0.75f)
        thresholdDb = juce::jmap (amount, 0.0f, 0.75f, -12.0f, -30.0f);
    else
        thresholdDb = juce::jmap (amount, 0.75f, 1.0f, -30.0f, -35.0f);

    updateCoefficients();
}

float BassRoomCompressor::computeGainDb (float levelDb) const
{
    const auto overDb = levelDb - thresholdDb;
    float compressedOverDb = overDb;

    if (overDb <= -kneeDb * 0.5f)
        compressedOverDb = overDb;
    else if (overDb >= kneeDb * 0.5f)
        compressedOverDb = overDb / ratio;
    else
    {
        const auto x = overDb + kneeDb * 0.5f;
        compressedOverDb = overDb + ((1.0f / ratio - 1.0f) * x * x) / (2.0f * kneeDb);
    }

    return juce::jmax (maxGainReductionDb, compressedOverDb - overDb);
}

void BassRoomCompressor::updateCoefficients()
{
    attackCoefficient = std::exp (-1.0f / (0.001f * attackMs * (float) sampleRate));
    releaseCoefficient = std::exp (-1.0f / (0.001f * releaseMs * (float) sampleRate));
}
