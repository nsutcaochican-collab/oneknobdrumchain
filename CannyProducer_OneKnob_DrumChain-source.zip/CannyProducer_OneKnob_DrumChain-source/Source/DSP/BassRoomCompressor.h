#pragma once

#include <JuceHeader.h>

class BassRoomCompressor
{
public:
    void prepare (double newSampleRate, int maxBlockSize, int numChannels);
    void reset();
    void setAmount (float newAmount);

    template <typename FloatType>
    void processBlock (juce::AudioBuffer<FloatType>& buffer)
    {
        const auto channels = juce::jmin (buffer.getNumChannels(), (int) envelope.size());
        const auto samples = buffer.getNumSamples();

        for (int channel = 0; channel < channels; ++channel)
        {
            auto* data = buffer.getWritePointer (channel);
            auto env = envelope[(size_t) channel];

            for (int sample = 0; sample < samples; ++sample)
            {
                const auto input = (float) data[sample];
                const auto rectified = std::abs (input);
                const auto coefficient = rectified > env ? attackCoefficient : releaseCoefficient;
                env = coefficient * env + (1.0f - coefficient) * rectified;

                const auto levelDb = juce::Decibels::gainToDecibels (env + 1.0e-9f);
                const auto gainDb = computeGainDb (levelDb);
                data[sample] = (FloatType) (input * juce::Decibels::decibelsToGain (gainDb));
            }

            envelope[(size_t) channel] = env;
        }
    }

private:
    float computeGainDb (float levelDb) const;
    void updateCoefficients();

    double sampleRate = 44100.0;
    float amount = 0.0f;
    float ratio = 2.0f;
    float thresholdDb = -12.0f;
    float attackMs = 80.0f;
    float releaseMs = 100.0f;
    float attackCoefficient = 0.0f;
    float releaseCoefficient = 0.0f;
    float kneeDb = 6.0f;
    float maxGainReductionDb = -5.0f;
    std::vector<float> envelope;
};
