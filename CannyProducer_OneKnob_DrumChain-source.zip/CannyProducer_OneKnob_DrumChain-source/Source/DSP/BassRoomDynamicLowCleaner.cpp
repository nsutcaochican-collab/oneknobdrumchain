#include "BassRoomDynamicLowCleaner.h"

void BassRoomDynamicLowCleaner::prepare (double newSampleRate, int maxBlockSize, int numChannels)
{
    juce::ignoreUnused (maxBlockSize);
    sampleRate = newSampleRate;

    const auto channels = (size_t) juce::jmax (1, numChannels);
    highPassFilters.resize (channels);
    lowPassFilters.resize (channels);
    detectorRms.assign (channels, 0.0f);
    gainSmoother.assign (channels, 1.0f);

    rmsCoefficient = std::exp (-1.0f / (0.160f * (float) sampleRate));
    updateFilters();
    reset();
}

void BassRoomDynamicLowCleaner::reset()
{
    for (auto& filter : highPassFilters)
        filter.reset();

    for (auto& filter : lowPassFilters)
        filter.reset();

    std::fill (detectorRms.begin(), detectorRms.end(), 0.0f);
    std::fill (gainSmoother.begin(), gainSmoother.end(), 1.0f);
}

void BassRoomDynamicLowCleaner::setAmount (float newAmount)
{
    amount = juce::jlimit (0.0f, 1.0f, newAmount);
    maxReductionDb = juce::jmap (amount, 0.0f, -2.5f);
}

void BassRoomDynamicLowCleaner::updateFilters()
{
    const auto highPass = juce::dsp::IIR::Coefficients<float>::makeHighPass (sampleRate, 20.0f);
    const auto lowPass = juce::dsp::IIR::Coefficients<float>::makeLowPass (sampleRate, 100.0f);

    for (auto& filter : highPassFilters)
        filter.coefficients = highPass;

    for (auto& filter : lowPassFilters)
        filter.coefficients = lowPass;
}

float BassRoomDynamicLowCleaner::computeReductionDb (float levelDb) const
{
    if (amount <= 0.0f)
        return 0.0f;

    const auto windowDb = 16.0f;
    const auto intensity = juce::jlimit (0.0f, 1.0f, (levelDb - thresholdDb) / windowDb);
    const auto eased = intensity * intensity * (3.0f - 2.0f * intensity);
    return maxReductionDb * eased;
}
