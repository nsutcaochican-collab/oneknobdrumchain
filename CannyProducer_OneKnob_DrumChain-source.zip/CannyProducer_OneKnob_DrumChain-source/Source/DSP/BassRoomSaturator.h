#pragma once

#include <JuceHeader.h>

class BassRoomSaturator
{
public:
    void prepare (double newSampleRate, int maxBlockSize, int numChannels);
    void reset();
    void setAmount (float newAmount);

    template <typename FloatType>
    void processBlock (juce::AudioBuffer<FloatType>& buffer)
    {
        const auto channels = juce::jmin (buffer.getNumChannels(), (int) highPassFilters.size());
        const auto samples = buffer.getNumSamples();

        for (int channel = 0; channel < channels; ++channel)
        {
            auto* data = buffer.getWritePointer (channel);

            for (int sample = 0; sample < samples; ++sample)
            {
                const auto input = (float) data[sample];
                auto band = highPassFilters[(size_t) channel].processSample (input);
                band = lowPassFilters[(size_t) channel].processSample (band);

                const auto driven = band * (1.0f + drive * 5.0f);
                const auto saturated = std::tanh (driven) / std::tanh (1.0f + drive * 5.0f);
                data[sample] = (FloatType) (input + mix * (saturated - band));
            }
        }
    }

private:
    using Filter = juce::dsp::IIR::Filter<float>;

    void updateFilters();

    double sampleRate = 44100.0;
    float amount = 0.0f;
    float drive = 0.0f;
    float mix = 0.0f;

    std::vector<Filter> highPassFilters;
    std::vector<Filter> lowPassFilters;
};
