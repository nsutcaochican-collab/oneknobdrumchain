#pragma once

#include <JuceHeader.h>

class BassRoomDynamicLowCleaner
{
public:
    void prepare (double newSampleRate, int maxBlockSize, int numChannels);
    void reset();
    void setAmount (float newAmount);

    template <typename FloatType>
    void processBlock (juce::AudioBuffer<FloatType>& buffer)
    {
        const auto channels = juce::jmin (buffer.getNumChannels(), (int) detectorRms.size());
        const auto samples = buffer.getNumSamples();

        for (int channel = 0; channel < channels; ++channel)
        {
            auto* data = buffer.getWritePointer (channel);
            auto rms = detectorRms[(size_t) channel];
            auto smoothedGain = gainSmoother[(size_t) channel];

            for (int sample = 0; sample < samples; ++sample)
            {
                const auto input = (float) data[sample];
                auto band = highPassFilters[(size_t) channel].processSample (input);
                band = lowPassFilters[(size_t) channel].processSample (band);

                rms = rmsCoefficient * rms + (1.0f - rmsCoefficient) * (band * band);
                const auto levelDb = juce::Decibels::gainToDecibels (std::sqrt (rms) + 1.0e-9f);
                const auto reductionDb = computeReductionDb (levelDb);
                const auto targetGain = juce::Decibels::decibelsToGain (reductionDb);

                smoothedGain += 0.0025f * (targetGain - smoothedGain);
                data[sample] = (FloatType) (input + (smoothedGain - 1.0f) * band);
            }

            detectorRms[(size_t) channel] = rms;
            gainSmoother[(size_t) channel] = smoothedGain;
        }
    }

private:
    using Filter = juce::dsp::IIR::Filter<float>;

    void updateFilters();
    float computeReductionDb (float levelDb) const;

    double sampleRate = 44100.0;
    float amount = 0.0f;
    float maxReductionDb = 0.0f;
    float thresholdDb = -30.0f;
    float rmsCoefficient = 0.0f;

    std::vector<Filter> highPassFilters;
    std::vector<Filter> lowPassFilters;
    std::vector<float> detectorRms;
    std::vector<float> gainSmoother;
};
