#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class BassRoomLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    BassRoomLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                           float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                           juce::Slider&) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool shouldDrawButtonAsHighlighted,
                           bool shouldDrawButtonAsDown) override;
};

class CannyOneKnobBassRoomAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Slider::Listener,
                                                       private juce::Timer
{
public:
    explicit CannyOneKnobBassRoomAudioProcessorEditor (CannyOneKnobBassRoomAudioProcessor&);
    ~CannyOneKnobBassRoomAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void sliderValueChanged (juce::Slider*) override;
    void timerCallback() override;
    void updateValueLabel();
    void updateLevelLabel();

    CannyOneKnobBassRoomAudioProcessor& audioProcessor;
    BassRoomLookAndFeel lookAndFeel;

    juce::Label brandLabel;
    juce::Label productLabel;
    juce::Label subtitleLabel;
    juce::ToggleButton activeButton;
    juce::Label activeLabel;
    juce::Slider drumChainSlider;
    juce::Label drumChainLabel;
    juce::Label valueLabel;
    juce::Slider levelSlider;
    juce::Label levelNameLabel;
    juce::Label levelValueLabel;

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> drumChainAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> levelAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> activeAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (CannyOneKnobBassRoomAudioProcessorEditor)
};
