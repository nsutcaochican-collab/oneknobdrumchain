#include "PluginEditor.h"

namespace
{
    const auto background = juce::Colour (0xff101217);
    const auto panel = juce::Colour (0xff171b22);
    const auto accent = juce::Colour (0xff42d6a4);
    const auto accentWarm = juce::Colour (0xffffc857);
    const auto text = juce::Colour (0xfff4f6f8);
    const auto mutedText = juce::Colour (0xff8d96a5);
}

BassRoomLookAndFeel::BassRoomLookAndFeel()
{
    setColour (juce::Slider::thumbColourId, accent);
    setColour (juce::Slider::rotarySliderFillColourId, accent);
    setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff303744));
}

void BassRoomLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                                            juce::Slider& slider)
{
    juce::ignoreUnused (slider);

    const auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (8.0f);
    const auto radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
    const auto centre = bounds.getCentre();
    const auto lineWidth = juce::jmax (7.0f, radius * 0.095f);
    const auto arcRadius = radius - lineWidth * 0.5f;
    const auto angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

    g.setColour (panel.brighter (0.04f));
    g.fillEllipse (bounds);

    g.setColour (juce::Colour (0xff080a0d));
    g.drawEllipse (bounds, 1.0f);

    juce::Path backgroundArc;
    backgroundArc.addCentredArc (centre.x, centre.y, arcRadius, arcRadius, 0.0f,
                                 rotaryStartAngle, rotaryEndAngle, true);
    g.setColour (juce::Colour (0xff303744));
    g.strokePath (backgroundArc, juce::PathStrokeType (lineWidth, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path valueArc;
    valueArc.addCentredArc (centre.x, centre.y, arcRadius, arcRadius, 0.0f,
                            rotaryStartAngle, angle, true);
    juce::ColourGradient gradient (accentWarm, bounds.getX(), bounds.getBottom(), accent, bounds.getRight(), bounds.getY(), false);
    g.setGradientFill (gradient);
    g.strokePath (valueArc, juce::PathStrokeType (lineWidth, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    const auto pointerLength = radius * 0.52f;
    const auto pointerThickness = 5.0f;
    juce::Path pointer;
    pointer.addRoundedRectangle (-pointerThickness * 0.5f, -pointerLength, pointerThickness, pointerLength * 0.72f, 2.0f);
    pointer.applyTransform (juce::AffineTransform::rotation (angle).translated (centre.x, centre.y));
    g.setColour (text);
    g.fillPath (pointer);

    g.setColour (juce::Colour (0xff0d1015));
    g.fillEllipse (centre.x - 7.0f, centre.y - 7.0f, 14.0f, 14.0f);
}

void BassRoomLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& button,
                                            bool shouldDrawButtonAsHighlighted,
                                            bool shouldDrawButtonAsDown)
{
    juce::ignoreUnused (shouldDrawButtonAsHighlighted, shouldDrawButtonAsDown);

    const auto bounds = button.getLocalBounds().toFloat().reduced (3.0f);
    const auto isOn = button.getToggleState();

    g.setColour (juce::Colour (0xff080a0d));
    g.fillEllipse (bounds);

    g.setColour (isOn ? accent : juce::Colour (0xff4a5058));
    g.fillEllipse (bounds.reduced (3.0f));

    g.setColour ((isOn ? accent : juce::Colour (0xff4a5058)).withAlpha (0.34f));
    g.drawEllipse (bounds.expanded (1.5f), 2.0f);
}

CannyOneKnobBassRoomAudioProcessorEditor::CannyOneKnobBassRoomAudioProcessorEditor (CannyOneKnobBassRoomAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setSize (420, 300);
    setLookAndFeel (&lookAndFeel);

    brandLabel.setText ("Canny Producer", juce::dontSendNotification);
    brandLabel.setJustificationType (juce::Justification::centred);
    brandLabel.setColour (juce::Label::textColourId, mutedText.brighter (0.18f));
    brandLabel.setFont (juce::FontOptions (15.0f, juce::Font::plain).withStyle ("SemiBold"));
    addAndMakeVisible (brandLabel);

    productLabel.setText ("OneKnob DrumChain", juce::dontSendNotification);
    productLabel.setJustificationType (juce::Justification::centred);
    productLabel.setColour (juce::Label::textColourId, text);
    productLabel.setFont (juce::FontOptions (26.0f, juce::Font::bold));
    addAndMakeVisible (productLabel);

    subtitleLabel.setText ("Tighten Drums With Punch", juce::dontSendNotification);
    subtitleLabel.setJustificationType (juce::Justification::centred);
    subtitleLabel.setColour (juce::Label::textColourId, mutedText);
    subtitleLabel.setFont (juce::FontOptions (12.0f));
    addAndMakeVisible (subtitleLabel);

    activeButton.setButtonText ({});
    activeButton.setClickingTogglesState (true);
    activeButton.setColour (juce::ToggleButton::tickColourId, accent);
    activeButton.setColour (juce::ToggleButton::tickDisabledColourId, juce::Colour (0xff4a5058));
    addAndMakeVisible (activeButton);

    activeLabel.setText ("Active", juce::dontSendNotification);
    activeLabel.setJustificationType (juce::Justification::centredLeft);
    activeLabel.setColour (juce::Label::textColourId, mutedText.brighter (0.15f));
    activeLabel.setFont (juce::FontOptions (11.0f));
    addAndMakeVisible (activeLabel);

    drumChainSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    drumChainSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    drumChainSlider.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f,
                                         juce::MathConstants<float>::pi * 2.75f,
                                         true);
    drumChainSlider.addListener (this);
    addAndMakeVisible (drumChainSlider);

    drumChainLabel.setText ("DrumChain", juce::dontSendNotification);
    drumChainLabel.setJustificationType (juce::Justification::centred);
    drumChainLabel.setColour (juce::Label::textColourId, mutedText.brighter (0.15f));
    drumChainLabel.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    addAndMakeVisible (drumChainLabel);

    valueLabel.setJustificationType (juce::Justification::centred);
    valueLabel.setColour (juce::Label::textColourId, text);
    valueLabel.setFont (juce::FontOptions (20.0f, juce::Font::bold));
    addAndMakeVisible (valueLabel);

    levelSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    levelSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    levelSlider.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f,
                                     juce::MathConstants<float>::pi * 2.75f,
                                     true);
    levelSlider.addListener (this);
    addAndMakeVisible (levelSlider);

    levelNameLabel.setText ("Level", juce::dontSendNotification);
    levelNameLabel.setJustificationType (juce::Justification::centred);
    levelNameLabel.setColour (juce::Label::textColourId, mutedText);
    levelNameLabel.setFont (juce::FontOptions (11.0f));
    addAndMakeVisible (levelNameLabel);

    levelValueLabel.setJustificationType (juce::Justification::centred);
    levelValueLabel.setColour (juce::Label::textColourId, text);
    levelValueLabel.setFont (juce::FontOptions (11.0f, juce::Font::bold));
    addAndMakeVisible (levelValueLabel);

    drumChainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        audioProcessor.getValueTreeState(), "drumchain", drumChainSlider);
    levelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        audioProcessor.getValueTreeState(), "level", levelSlider);
    activeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        audioProcessor.getValueTreeState(), "active", activeButton);

    updateValueLabel();
    updateLevelLabel();
    startTimerHz (20);
}

CannyOneKnobBassRoomAudioProcessorEditor::~CannyOneKnobBassRoomAudioProcessorEditor()
{
    drumChainSlider.removeListener (this);
    levelSlider.removeListener (this);
    setLookAndFeel (nullptr);
}

void CannyOneKnobBassRoomAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (background);

    auto bounds = getLocalBounds().toFloat();
    juce::ColourGradient gradient (juce::Colour (0xff1d2630), bounds.getX(), bounds.getY(),
                                   background, bounds.getRight(), bounds.getBottom(), false);
    g.setGradientFill (gradient);
    g.fillRect (bounds);

    g.setColour (juce::Colour (0x22000000));
    g.fillRoundedRectangle (bounds.reduced (18.0f).withY (96.0f).withHeight (170.0f), 8.0f);
}

void CannyOneKnobBassRoomAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (22);

    brandLabel.setBounds (area.getX(), 18, area.getWidth(), 20);
    productLabel.setBounds (area.getX(), 36, area.getWidth(), 32);
    subtitleLabel.setBounds (area.getX(), 66, area.getWidth(), 18);

    activeButton.setBounds (342, 17, 22, 22);
    activeLabel.setBounds (364, 18, 48, 20);

    drumChainSlider.setBounds ((getWidth() - 170) / 2, 100, 170, 160);
    drumChainLabel.setBounds (area.getX(), 238, area.getWidth(), 20);
    valueLabel.setBounds (area.getX(), 258, area.getWidth(), 28);

    levelSlider.setBounds (306, 204, 54, 54);
    levelNameLabel.setBounds (292, 252, 82, 16);
    levelValueLabel.setBounds (292, 267, 82, 16);
}

void CannyOneKnobBassRoomAudioProcessorEditor::sliderValueChanged (juce::Slider* slider)
{
    if (slider == &drumChainSlider)
        updateValueLabel();
    else if (slider == &levelSlider)
        updateLevelLabel();
}

void CannyOneKnobBassRoomAudioProcessorEditor::timerCallback()
{
    updateValueLabel();
    updateLevelLabel();
}

void CannyOneKnobBassRoomAudioProcessorEditor::updateValueLabel()
{
    valueLabel.setText (juce::String (juce::roundToInt (drumChainSlider.getValue() * 100.0)) + "%", juce::dontSendNotification);
}

void CannyOneKnobBassRoomAudioProcessorEditor::updateLevelLabel()
{
    const auto value = (float) levelSlider.getValue();
    const auto prefix = value > 0.0f ? "+" : "";
    levelValueLabel.setText (prefix + juce::String (value, 1) + " dB", juce::dontSendNotification);
}
