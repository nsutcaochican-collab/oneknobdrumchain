Unicode true
RequestExecutionLevel admin

!define PRODUCT_NAME "Canny Producer OneKnob DrumChain"
!define PRODUCT_VERSION "1.0.0"
!define PRODUCT_PUBLISHER "Canny Producer"
!define VST3_NAME "Canny Producer OneKnob DrumChain.vst3"

Name "${PRODUCT_NAME}"
OutFile "CannyProducer_OneKnob_DrumChain_Installer.exe"
InstallDir "$PROGRAMFILES64\VSTPlugins"
InstallDirRegKey HKLM "Software\Canny Producer\OneKnob DrumChain" "InstallDir"

!include "MUI2.nsh"

!define MUI_ABORTWARNING
!define MUI_ICON "${NSISDIR}\Contrib\Graphics\Icons\modern-install.ico"
!define MUI_UNICON "${NSISDIR}\Contrib\Graphics\Icons\modern-uninstall.ico"

!insertmacro MUI_PAGE_WELCOME
!define MUI_DIRECTORYPAGE_TEXT_TOP "Choose where ${PRODUCT_NAME} will install the VST3 plugin. The recommended path is C:\Program Files\VSTPlugins."
!define MUI_DIRECTORYPAGE_TEXT_DESTINATION "VST3 install path"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

Section "VST3 Plugin" SecVST3
    SetOutPath "$INSTDIR"
    RMDir /r "$INSTDIR\${VST3_NAME}"
    File /r "${VST3_NAME}"
    WriteRegStr HKLM "Software\Canny Producer\OneKnob DrumChain" "InstallDir" "$INSTDIR"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Canny Producer OneKnob DrumChain" "DisplayName" "${PRODUCT_NAME}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Canny Producer OneKnob DrumChain" "DisplayVersion" "${PRODUCT_VERSION}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Canny Producer OneKnob DrumChain" "Publisher" "${PRODUCT_PUBLISHER}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Canny Producer OneKnob DrumChain" "InstallLocation" "$INSTDIR"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Canny Producer OneKnob DrumChain" "UninstallString" "$INSTDIR\Uninstall Canny Producer OneKnob DrumChain.exe"
    WriteUninstaller "$INSTDIR\Uninstall Canny Producer OneKnob DrumChain.exe"
SectionEnd

Section "Uninstall"
    RMDir /r "$INSTDIR\${VST3_NAME}"
    Delete "$INSTDIR\Uninstall Canny Producer OneKnob DrumChain.exe"
    DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Canny Producer OneKnob DrumChain"
    DeleteRegKey HKLM "Software\Canny Producer\OneKnob DrumChain"
SectionEnd
