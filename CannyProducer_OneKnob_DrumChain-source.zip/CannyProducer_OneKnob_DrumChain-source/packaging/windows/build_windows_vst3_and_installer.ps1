param(
    [string] $JuceDir = "$PSScriptRoot\..\..\..\JUCE",
    [string] $BuildDir = "$PSScriptRoot\..\..\build-windows",
    [string] $PackageDir = "$PSScriptRoot\..\..\dist-windows"
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Resolve-Path "$PSScriptRoot\..\.."
$InstallerScript = Join-Path $PSScriptRoot "CannyProducer_OneKnob_DrumChain.nsi"

if (-not (Test-Path $JuceDir)) {
    throw "JUCE 8 was not found at '$JuceDir'. Pass -JuceDir C:\Path\To\JUCE."
}

$cmake = Get-Command cmake -ErrorAction Stop
$makensis = Get-Command makensis -ErrorAction Stop

cmake -S $ProjectRoot -B $BuildDir -G "Visual Studio 17 2022" -A x64 -DJUCE_DIR="$JuceDir"
cmake --build $BuildDir --config Release --target CannyOneKnobBassRoom_VST3

$vst3 = Join-Path $BuildDir "CannyOneKnobBassRoom_artefacts\Release\VST3\Canny Producer OneKnob DrumChain.vst3"
if (-not (Test-Path $vst3)) {
    throw "VST3 build output was not found at '$vst3'."
}

New-Item -ItemType Directory -Force -Path $PackageDir | Out-Null
Copy-Item -Recurse -Force $vst3 $PackageDir
Copy-Item -Force $InstallerScript $PackageDir

Push-Location $PackageDir
try {
    & $makensis.Source "CannyProducer_OneKnob_DrumChain.nsi"
}
finally {
    Pop-Location
}

Write-Host ""
Write-Host "Built Windows installer:"
Write-Host (Join-Path $PackageDir "CannyProducer_OneKnob_DrumChain_Installer.exe")
Write-Host ""
Write-Host "Installer default path:"
Write-Host "C:\Program Files\VSTPlugins"
