# Windows VST3 Build and Installer

This project can build a 64-bit Windows VST3 and package it into an installer `.exe`.

## Requirements

- Windows 10 or newer, 64-bit
- Visual Studio 2022 with C++ desktop workload
- CMake
- JUCE 8
- NSIS 3

## Build

Open PowerShell from the project root and run:

```powershell
.\packaging\windows\build_windows_vst3_and_installer.ps1 -JuceDir C:\Path\To\JUCE
```

The script builds:

- `Canny Producer OneKnob DrumChain.vst3`
- `CannyProducer_OneKnob_DrumChain_Installer.exe`

## Installer Behavior

The installer shows the install path in the UI and defaults to:

```text
C:\Program Files\VSTPlugins
```

The user can change the path during installation.
