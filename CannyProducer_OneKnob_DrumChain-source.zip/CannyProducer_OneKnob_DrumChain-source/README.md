# Canny Producer OneKnob DrumChain

One-knob drum-chain tightening plugin for macOS, built with JUCE 8 and CMake.

## Build Requirements

- macOS 11 or newer
- Xcode
- CMake 3.22 or newer
- JUCE 8 installed locally

## Configure With Xcode

From this folder:

```sh
cmake -S . -B build -G Xcode -DJUCE_DIR=/path/to/JUCE
```

If `JUCE_DIR` points to an installed JUCE CMake package instead of a checkout, CMake will use that too. You can also set `CMAKE_PREFIX_PATH`:

```sh
cmake -S . -B build -G Xcode -DCMAKE_PREFIX_PATH=/path/to/JUCE
```

## Compile AU and VST3

```sh
cmake --build build --config Release
```

The CMake target exports both:

- AU: `Canny Producer OneKnob DrumChain.component`
- VST3: `Canny Producer OneKnob DrumChain.vst3`

The compiled plugins are written inside the build folder:

- `build/CannyOneKnobBassRoom_artefacts/Release/AU/Canny Producer OneKnob DrumChain.component`
- `build/CannyOneKnobBassRoom_artefacts/Release/VST3/Canny Producer OneKnob DrumChain.vst3`

To install them for the current user, copy them to:

- `~/Library/Audio/Plug-Ins/Components/`
- `~/Library/Audio/Plug-Ins/VST3/`

## Signal Flow

Input -> Compressor -> Dynamic Low Cleaner -> High-Mid Saturator -> Level -> Output

The `DrumChain` parameter controls compression strength, dynamic low cleanup, and harmonic enhancement together. `Level` applies final output trim, and `Active` smoothly bypasses the processing chain.

## Windows CI

The repository includes a GitHub Actions workflow at `.github/workflows/windows-build.yml`.

It builds the Windows x64 VST3, creates an NSIS installer, uploads release artifacts, and attaches the artifacts automatically when a `v*` tag is pushed.

The Windows installer defaults to:

```text
C:\Program Files\VSTPlugins
```
